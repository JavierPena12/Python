import cv2
import numpy as np

img =cv2.imread('CIRCULO2.jpg')
hsv=cv2.cvtColor(img, cv2.COLOR_BGR2HSV)

verde_bajo = np.array([36,100,20])
verde_alto = np.array([90,255,255])

morado_bajo = np.array([146, 100, 20])
morado_alto = np.array([170, 255, 255])

naranja_bajo = np.array([11,100,20])
naranja_alto = np.array([19,255,255])

maskV = cv2.inRange(hsv,verde_bajo,verde_alto)
maskM= cv2.inRange(hsv,morado_bajo,morado_alto)
maskN= cv2.inRange(hsv,naranja_bajo,naranja_alto)
mask_union = cv2.bitwise_or(maskV, maskM)
mask_union2 = cv2.bitwise_or(mask_union, maskN)

cv2.imshow('foto original',img)
cv2.imshow('foto Verde+Morado+Naranja',mask_union2)
