import cv2
import numpy as np

img =cv2.imread('CIRCULO2.jpg')
hsv=cv2.cvtColor(img, cv2.COLOR_BGR2HSV)

rojo_bajo = np.array([0, 100, 20])
rojo_alto = np.array([10, 255, 255])

morado_bajo = np.array([146, 100, 20])
morado_alto = np.array([170, 255, 255])

azul_bajo = np.array([100,50,50])
azul_alto = np.array([130,255,255])

verde_bajo = np.array([36,100,20])
verde_alto = np.array([90,255,255])

amarillo_bajo = np.array([20,100,20])
amarillo_alto = np.array([32,255,255])

maskRojo = cv2.inRange(hsv,rojo_bajo,rojo_alto)
maskMora = cv2.inRange(hsv,morado_bajo,morado_alto)
maskAzul = cv2.inRange(hsv,azul_bajo,azul_alto)
maskVerde = cv2.inRange(hsv,verde_bajo,verde_alto)
maskAma = cv2.inRange(hsv,amarillo_bajo,amarillo_alto)

mask_union1 = cv2.bitwise_or(maskRojo, maskMora)
mask_union2 = cv2.bitwise_or(maskAzul, maskVerde)
mask_union3 = cv2.bitwise_or(mask_union1,mask_union2)
mask_union4 = cv2.bitwise_or(mask_union3,maskAma)

cv2.imshow('foto original',img)
cv2.imshow('foto Todo menos Naranja',mask_union4)
