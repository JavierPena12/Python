class covid19(): 
    def __init__(self, estado, Confirmados, Negativos, Fallecidos): 
        self.estado = estado 
        self.Confirmados = Confirmados  
        self.Negativos = Negativos 
        self.Fallecidos = Fallecidos
        
    def covid(self):
        presentacion = ("Estado:{}, Casos confirmados:{}, Casos negativos:{}, Fallecidos:{} ") 
        print(presentacion.format( self.estado, self.Confirmados, self.Negativos, self.Fallecidos  )) 

Persona1 = covid19("Quintana Roo", 11759, 7921, 1640) 
Persona1.covid() 

class covid2():
    def __init__ (self, estado, Confirmados, Negativos, Fallecidos):
        self.estado = estado 
        self.Confirmados = Confirmados  
        self.Negativos = Negativos 
        self.Fallecidos = Fallecidos
    def presentar(self):
        presentacion = ("Estado:{}, Casos confirmados:{}, Casos negativos:{}, Decesos:{} ") 
        print(presentacion.format( self.estado, self.Confirmados, self.Negativos, self.Fallecidos  )) 

Persona1 = covid2("San Luis Potosi", 22910, 27386, 1664) 
Persona1.presentar()


  
