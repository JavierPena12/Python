from numpy import *
from pylab import *
from matplotlib import pyplot

Estados = ["Sinaloa", "Sonora", "Tabasco", "MuertesTotales"]

Valores = [3150, 2853, 2755, 8758]

Colores = ["red","blue","yellow","black"]

pyplot.xlabel('Estados')
pyplot.ylabel('Personas')

pyplot.title('Muertos por covid en 3 estados')

pyplot.bar(Estados, height=Valores, color=Colores, width=0.5)

pyplot.show()
