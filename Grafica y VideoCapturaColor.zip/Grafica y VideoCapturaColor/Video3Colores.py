import cv2
import numpy as np
 
captura = cv2.VideoCapture(0)
 
while(1):
    _, imagen = captura.read()
    hsv = cv2.cvtColor(imagen, cv2.COLOR_BGR2HSV)

    rojo_bajo = np.array([0, 100, 20], dtype=np.uint8)
    rojo_alto = np.array([5, 255, 255], dtype=np.uint8)

    amarillo_bajo = np.array([15,100,20], dtype=np.uint8)
    amarillo_alto = np.array([45,255,255], dtype=np.uint8)

    azul_bajo = np.array([100,100,20], dtype=np.uint8)
    azul_alto = np.array([125,255,255], dtype=np.uint8)
    
    maskRojo = cv2.inRange(hsv,rojo_bajo,rojo_alto)
    maskAma = cv2.inRange(hsv,amarillo_bajo,amarillo_alto)
    maskAzul = cv2.inRange(hsv,azul_bajo,azul_alto)

    mask_union1 = cv2.bitwise_or(maskRojo, maskAma)
    mask_union2 = cv2.bitwise_or(mask_union1, maskAzul)
    
    moments = cv2.moments(mask_union2)
    area = moments['m00']
 
    print area
    if(area > 2000000):
         
        x = int(moments['m10']/moments['m00'])
        y = int(moments['m01']/moments['m00']) 
        print ("x = ", x)
        print ("y = ", y)
 
        cv2.rectangle(imagen, (x, y), (x+2, y+2),(0,0,255), 2)
     
    cv2.imshow('mask', mask_union2)
    cv2.imshow('Camara', imagen)
    tecla = cv2.waitKey(5) & 0xFF
    if tecla == 27:
        break
 
cv2.destroyAllWindows()
