#Base de datos con informacion de Covid en estados de Mexico
"[] {} <>"
from tkinter import *
from tkinter.ttk import *
import mysql.connector

mydb = mysql.connector.connect(
    host="localhost",
    user="root",
    password="",
    database="covid"
)

def insertar():
    mycursor=mydb.cursor()
    sql="INSERT INTO estados (control,estado) VALUES (%s,%s)"
    ct=input("numero de estado:")
    es=input("estado:")
    val=(ct,es)
    mycursor.execute(sql,val)

    mydb.commit()
    insertar1()
def insertar1():
    mycursor=mydb.cursor()
    sql="INSERT INTO datos (control,confirmados,negativos,\
    sospechosos,activos,recuperados,fallecidos) VALUES (%s,%s,%s,%s,%s,%s,$s)"
    c=input("control:")
    o=input("confirmados:")
    n=input("negativos:")
    s=input("sospechosos:")
    a=input("activos:")
    r=input("recuperados:")
    f=input("fallecidos:")
    val=(c,o,n,s,a,r,f)
    mycursor.execute(sql,val)

    mydb.commit()
    print(mycursor.rowcount,"Agregado.")

#Datos
def estados():
    print('Confirmados','Negativos','Sospechosos','Activos','Recuperados','Fallecidos')
    if combo.get()=='SanLuisPotosi':
        mycursor=mydb.cursor()

        sql="SELECT \
            datos.Confirmados AS ala, \
            datos.Negativos AS fav, \
            datos.Sospechosos AS ele, \
            datos.Activos AS fov, \
            datos.Recuperados AS fev, \
            datos.Fallecidos AS fiv, \
            prueba.controlE AS olo \
            FROM datos\
            INNER JOIN prueba ON datos.control=prueba.controlE where controlE='1'"

        mycursor.execute(sql)
        myresult=mycursor.fetchall()

        for x in myresult:
            print (x)
    if combo.get()=='QuintanaRoo':
        mycursor=mydb.cursor()

        sql="SELECT \
            datos.Confirmados AS ala, \
            datos.Negativos AS fav, \
            datos.Sospechosos AS ele, \
            datos.Activos AS fov, \
            datos.Recuperados AS fev, \
            datos.Fallecidos AS fiv, \
            prueba.controlE AS olo \
            FROM datos\
            INNER JOIN prueba ON datos.control=prueba.controlE where controlE='2'"

        mycursor.execute(sql)
        myresult=mycursor.fetchall()

        for x in myresult:
            print (x)
    if combo.get()=='Sinaloa':
        mycursor=mydb.cursor()

        sql="SELECT \
            datos.Confirmados AS ala, \
            datos.Negativos AS fav, \
            datos.Sospechosos AS ele, \
            datos.Activos AS fov, \
            datos.Recuperados AS fev, \
            datos.Fallecidos AS fiv, \
            prueba.controlE AS olo \
            FROM datos\
            INNER JOIN prueba ON datos.control=prueba.controlE where controlE='3'"

        mycursor.execute(sql)
        myresult=mycursor.fetchall()

        for x in myresult:
            print (x)
    if combo.get()=='Sonora':
        mycursor=mydb.cursor()

        sql="SELECT \
            datos.Confirmados AS ala, \
            datos.Negativos AS fav, \
            datos.Sospechosos AS ele, \
            datos.Activos AS fov, \
            datos.Recuperados AS fev, \
            datos.Fallecidos AS fiv, \
            prueba.controlE AS olo \
            FROM datos\
            INNER JOIN prueba ON datos.control=prueba.controlE where controlE='4'"

        mycursor.execute(sql)
        myresult=mycursor.fetchall()

        for x in myresult:
            print (x)
     if combo.get()=='Tabasco':
        mycursor=mydb.cursor()

        sql="SELECT \
            datos.Confirmados AS ala, \
            datos.Negativos AS fav, \
            datos.Sospechosos AS ele, \
            datos.Activos AS fov, \
            datos.Recuperados AS fev, \
            datos.Fallecidos AS fiv, \
            prueba.controlE AS olo \
            FROM datos\
            INNER JOIN prueba ON datos.control=prueba.controlE where controlE='5'"

        mycursor.execute(sql)
        myresult=mycursor.fetchall()

        for x in myresult:
            print (x)
    
#Pantalla
windows = Tk()
windows.title('Casos de Covid en 5 estados de Mexico')
windows.geometry("390x170")

foto=PhotoImage(file='fondo2.png')
fondo=Label(windows,image=foto).place(x=0, y=0)

texto=StringVar()
texto.set ('Estados: ')

combo = Combobox(windows)
combo.place(x=10,y=20)                                                     
combo['values'] = [
    'QuintanaRoo',
    'SanLuisPotosi',
    'Sinaloa',
    'Sonora',
    'Tabasco'
    ]
combo.current(0)

boton=Button(windows,command=guardar,text='Insertar.')
boton2=Button(windows,command=estados,text='Confirmar.')
etiqueta=Label(windows,textvariable=texto)
etiqueta.place(x=40,y=400)                                                    
boton.place(x=200,y=130)                                                    
boton2.place(x=100,y=130)                                                    

windows.mainloop()
