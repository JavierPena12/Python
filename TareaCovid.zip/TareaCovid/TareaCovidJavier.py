"[] {} <>"

import json
from tkinter import *
from tkinter.ttk import *

QR={}
QR['datos']=[]
QR['datos'].append({
    'Confirmados':11759,
    'Negativos':7921,
    'Sospechosos':671,
    'Activos':347,
    'Recuperados':7943,
    'Fallecidos':1640
    })
SLP={}
SLP['datos']=[]
SLP['datos'].append({
    'Confirmados':22910,
    'Negativos':27386,
    'Sospechosos':1739,
    'Activos':637,
    'Recuperados':28585,
    'Fallecidos':1664
    })
SIN={}
SIN['datos']=[]
SIN['datos'].append({
    'Confirmados':1815,
    'Negativos':14464,
    'Sospechosos':1260,
    'Activos':364,
    'Recuperados':11692,
    'Fallecidos':3150
    })
SON={}
SON['datos']=[]
SON['datos'].append({
    'Confirmados':24418,
    'Negativos':20782,
    'Sospechosos':1779,
    'Activos':501,
    'Recuperados':18017,
    'Fallecidos':2853
    })
TA={}
TA['datos']=[]
TA['datos'].append({
    'Confirmados':31691,
    'Negativos':33906,
    'Sospechosos':676,
    'Activos':736,
    'Recuperados':25740,
    'Fallecidos':2755
    })
def estados():
    if (combo.get()) == 'QuintanaRoo':
        print("Casos en Quintana Roo:")
        print(QR['datos'])
    elif (combo.get()) == 'SanLuisPotosi':
        print("Casos en San Luis Potosi:")
        print(SLP['datos'])
    elif (combo.get()) == 'Sinaloa':
        print("Casos en Sinaloa:")
        print(SIN['datos'])
    elif (combo.get()) == 'Sonora':
        print("Casos en Sonora:")
        print(SON['datos'])
    elif (combo.get()) == 'Tabasco':
         print("Casos en Tabasco:")
         print(TA['datos'])
def guardar():
    if combo.get()=='QuintanaRoo':
        with open('QRcovid.json','w') as file:
            json.dump(QR,file)
    elif combo.get()=='SanLuisPotosi':
        with open('SLPcovid.json','w') as file:
            json.dump(SLP,file)
    elif combo.get()=='Sinaloa':
        with open('SINcovid.json','w') as file:
            json.dump(SIN,file)
    elif combo.get()=='Sonora':
        with open('SONcovid.json','w') as file:
            json.dump(SON,file)
    elif combo.get()=='Tabasco':
        with open('TAcovid.json','w') as file:
            json.dump(TA,file)
    print("Informacion guardada")

windows = Tk()
windows.title('Casos de Covid-19 en estados de Mexico')
windows.geometry("390x170")

foto=PhotoImage(file='fondo2.png')
fondo=Label(windows,image=foto).place(x=0, y=0)

texto=StringVar()
texto.set ('Estados: ')

combo = Combobox(windows)
combo.place(x=10,y=20)                                                     
combo['values'] = [
    'QuintanaRoo',
    'SanLuisPotosi',
    'Sinaloa',
    'Sonora',
    'Tabasco'
    ]
combo.current(0)

boton=Button(windows,command=guardar,text='Guardar info.')
boton2=Button(windows,command=estados,text='Confirmar')
etiqueta=Label(windows,textvariable=texto)
etiqueta.place(x=40,y=400)                                                    
boton.place(x=200,y=130)                                                    
boton2.place(x=100,y=130)                                                    

windows.mainloop()
