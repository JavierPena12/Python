import cv2
import tkinter
from tkinter import *

ventana=tkinter.Tk()
ventana.title('Programa para tomar fotos.')
ventana.geometry('640x480')

def Foto2():
    Foto()

def Foto():
    camara= cv2.VideoCapture(0)
    leido,frame=camara.read()
    if leido==True:
        cv2.imwrite('CAPTURA.png',frame)
        print('Se ha tomado la foto.')
    else:
        print('Error: su camara no existe o está apagada')
        camara.release()
    foto=PhotoImage(file='CAPTURA.png')
    fondo=Label(ventana,image=foto).place(x=0,y=0)
    
    texto=StringVar()
    texto.set("Se ha tomado una captura,¿desea realizar otra?")
    etiqueta=Label(ventana,textvariable=texto)
    etiqueta.place(x=20,y=20)
    boton=Button(ventana,text='Si.',command=Foto2).place(x=30,y=60)
    boton=Button(ventana,text='No, salir.',command=ventana.destroy).place(x=60,y=60)

    ventana.mainloop()
Foto()


    


